using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("To odważne, że wybierasz tę grę");

    Console.WriteLine ("Jak cię zwą?");

    string NamePlayerOne = Console.ReadLine ();

    Console.WriteLine ("Witaj, " + NamePlayerOne);

    Console.WriteLine ("A twoje imię drugi graczu?");

    string NamePlayerTwo = Console.ReadLine ();

    Console.WriteLine ("Witaj, " + NamePlayerTwo);

    Console.WriteLine (NamePlayerOne + ", wybierz papier, kamień lub nożyce");

    Console.WriteLine (NamePlayerTwo + ", wybierz papier, kamień lub nożyce");

    Console.WriteLine (NamePlayerOne + ", wpisz swój wybór");

    string ChoiceOne = Console.ReadLine ();

    Console.WriteLine (NamePlayerOne + ", twój wybór to " + ChoiceOne);

    Console.Clear();

    Console.WriteLine (NamePlayerTwo + ", wpisz swój wybór");

    string ChoiceTwo = Console.ReadLine (); 

    Console.WriteLine (NamePlayerTwo + ", twój wybór to " + ChoiceTwo);

    Console.Clear();
    






  }
}